// src/schemas/role.ts
export type Role = {
    id: string
    name: string
    createdAt: string
    updatedAt: string
  }
  