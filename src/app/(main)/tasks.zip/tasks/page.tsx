import { Metadata } from "next"
import { TaskBoard } from "./components/TaskBoard"

export const metadata: Metadata = {
  title: "Tasks",
  description: "A task and issue tracker built using Tanstack Table.",
}

export default function Page() {
  return <TaskBoard />
}