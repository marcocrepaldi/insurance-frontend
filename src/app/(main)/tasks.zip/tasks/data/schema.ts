import { z } from "zod"

export const taskSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  status: z.enum([
    "PENDING",
    "IN_PROGRESS",
    "WAITING_APPROVAL",
    "APPROVED",
    "REJECTED",
  ]),
  label: z.enum(["BUG", "FEATURE", "URGENT", "IMPROVEMENT"]).nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
  createdBy: z.object({
    id: z.string(),
    name: z.string(),
    email: z.string(),
    roleId: z.string(),
    createdAt: z.string(),
    updatedAt: z.string(),
  }),
  assignedTo: z.object({
    id: z.string(),
    name: z.string(),
    email: z.string(),
    roleId: z.string(),
    createdAt: z.string(),
    updatedAt: z.string(),
  }),
})

export type Task = z.infer<typeof taskSchema>
