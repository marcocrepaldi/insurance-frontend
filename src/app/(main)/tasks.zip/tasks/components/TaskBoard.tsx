"use client"

import Image from "next/image"
import { columns } from "./columns"
import { DataTable } from "./data-table"
import { UserNav } from "./user-nav"
import { useTasks } from "../components/hooks/use-tasks"
import { SectionCards } from "@/components/ui/section-cards"
import { Task } from "../data/schema"

export function TaskBoard() {
  const { tasks, isLoading } = useTasks()

  if (isLoading) {
    return <div className="p-8">Carregando tarefas...</div>
  }

  return (
    <>
      {/* Imagens alternativas para mobile */}
      <div className="md:hidden">
        <Image
          src="/examples/tasks-light.png"
          width={1280}
          height={998}
          alt="Ilustração de tarefas"
          className="block dark:hidden"
        />
        <Image
          src="/examples/tasks-dark.png"
          width={1280}
          height={998}
          alt="Ilustração de tarefas (dark)"
          className="hidden dark:block"
        />
      </div>

      {/* Painel principal */}
      <div className="hidden h-full flex-1 flex-col space-y-8 p-8 md:flex">
        <div className="flex items-center justify-between space-y-2">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Welcome back!</h2>
            <p className="text-muted-foreground">
              Aqui estão suas tarefas registradas no sistema!
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <UserNav />
          </div>
        </div>

        <SectionCards />
        <DataTable<Task, unknown> columns={columns} data={tasks} />
      </div>
    </>
  )
}
