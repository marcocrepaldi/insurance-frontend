import useSWR from "swr"
import { taskSchema, Task } from "../data/schema"

const fetcher = async (url: string): Promise<Task[]> => {
  const token = localStorage.getItem("jwt_token")

  if (!token) {
    console.warn("⚠️ Token não encontrado em localStorage (jwt_token)")
    throw new Error("Token de autenticação ausente.")
  }

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })

  if (!res.ok) {
    console.error(`❌ Erro ao buscar tarefas: ${res.status}`)
    throw new Error(`Erro ${res.status} ao buscar tarefas`)
  }

  const data = await res.json()

  console.log("🔍 API /tasks response:", data)

  // Validação com Zod
  return data.map((item: any) => taskSchema.parse(item))
}

export function useTasks() {
  const { data, error, isValidating } = useSWR<Task[]>(
    "https://insurance-api-production-55fa.up.railway.app/api/tasks",
    fetcher
  )

  return {
    tasks: data || [],
    isLoading: !data && !error,
    isError: !!error,
    isValidating,
  }
}
