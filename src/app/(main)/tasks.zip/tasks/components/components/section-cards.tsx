"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useTasks } from "../hooks/use-tasks"
import type { Task } from "../data/schema"

export function SectionCards() {
  const { tasks } = useTasks()

  const total = tasks.length
  const pending = tasks.filter((t: Task) => t.status === "PENDING").length
  const inProgress = tasks.filter((t: Task) => t.status === "IN_PROGRESS").length
  const waitingApproval = ((t: Task) => t.status === "WAITING_APPROVAL").length
  const approved = ((t: Task) => t.status === "APPROVED").length
  const rejected = ((t: Task) =>  t.status === "REJECTED").length

  const cards = [
    { title: "Total de Tarefas", value: total },
    { title: "Pendentes", value: pending },
    { title: "Em Andamento", value: inProgress },
    { title: "Aguardando Aprovação", value: waitingApproval },
    { title: "Aprovadas", value: approved },
    { title: "Rejeitadas", value: rejected },
  ]

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader>
            <CardTitle>{card.title}</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold">{card.value}</CardContent>
        </Card>
      ))}
    </div>
  )
}