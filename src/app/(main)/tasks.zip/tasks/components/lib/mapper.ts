import { Task } from "../data/schema"

export function mapTaskToTable(task: Task) {
  return {
    id: task.id,
    title: task.title,
    status: task.status,
    label: task.label ?? "Sem rótulo", // fallback
    description: task.description,
  }
}
