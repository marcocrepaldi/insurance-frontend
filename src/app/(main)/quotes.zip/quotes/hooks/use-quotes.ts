import useSWR from "swr"
import { InsuranceQuote } from "../types/index"
import { useAuth } from "../hooks/use-auth"

export function useQuotes() {
  const { token } = useAuth()

  const fetcher = async (url: string): Promise<InsuranceQuote[]> => {
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    if (!res.ok) throw new Error("Erro ao buscar cotações")
    return res.json()
  }

  const { data, error, isValidating, mutate } = useSWR(
    token ? "/api/insurance-quotes" : null,
    fetcher
  )

  const isLoading = !data && !error

  return {
    quotes: data || [],
    isLoading,
    isValidating,
    isError: !!error,
    mutate,
  }
}
