"use client"

import { useQuotes } from "../hooks/use-quotes"
import { useIsMobile } from "@/hooks/use-mobile"
import { useState } from "react"
import { InsuranceQuote } from "../types/index"
import { formatCurrency, formatDate } from "../lib/formatters"

import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { LoaderIcon } from "lucide-react"

export function DataTable() {
  const { quotes, isLoading, isValidating } = useQuotes()
  const isMobile = useIsMobile()
  const [selectedQuote, setSelectedQuote] = useState<InsuranceQuote | null>(null)

  return (
    <Tabs defaultValue="quotes" className="w-full">
      <TabsContent value="quotes">
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Título</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Produtor</TableHead>
                <TableHead className="text-right">Prêmio Estimado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center">
                    <LoaderIcon className="mx-auto animate-spin" />
                  </TableCell>
                </TableRow>
              ) : quotes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center">
                    Nenhuma cotação encontrada.
                  </TableCell>
                </TableRow>
              ) : (
                quotes.map((quote) => (
                  <TableRow key={quote.id}>
                    <TableCell>
                      <Sheet>
                        <SheetTrigger asChild>
                          <Button
                            variant="link"
                            className="px-0 text-left"
                            onClick={() => setSelectedQuote(quote)}
                          >
                            {quote.title}
                          </Button>
                        </SheetTrigger>
                        <SheetContent side="right">
                          <div className="flex flex-col gap-4 p-4">
                            <h2 className="text-lg font-semibold">
                              {quote.title}
                            </h2>
                            <p className="text-sm text-muted-foreground">
                              Criado por: {quote.createdBy?.name || "-"}
                            </p>
                            <p className="text-sm">
                              Cliente: {quote.client?.name}<br />
                              Produtor: {quote.producer?.name}
                            </p>
                            <p className="text-sm">
                              Data de decisão esperada: {formatDate(quote.expectedDecisionDate ?? "")}
                            </p>
                            <p className="text-sm">
                              Prêmio estimado: {formatCurrency(quote.expectedPremium ?? 0)}
                            </p>
                            <p className="text-sm">
                              Criado em: {formatDate(quote.createdAt ?? "")}
                            </p>
                          </div>
                        </SheetContent>
                      </Sheet>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{quote.stage}</Badge>
                    </TableCell>
                    <TableCell>{quote.client?.name}</TableCell>
                    <TableCell>{quote.producer?.name}</TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(quote.expectedPremium ?? 0)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </TabsContent>
    </Tabs>
  )
}
