

import { ChartAreaInteractive } from "@/components/chart-area-interactive"
import { SectionCards } from "@/components/section-cards"
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar"
import { ComponentBarChartInreractive } from "../../components/bar-chart-interactive"
import { DataTableDemo } from "../../components/data-table-proposals"



export default function Page() {
  return (
    <SidebarProvider>
      <SidebarInset>
        <div className="flex flex-1 flex-col bg-background text-foreground">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              {/* Cartões com estatísticas principais */}
              <SectionCards />

              {/* Gráfico interativo */}
              <div className="px-4 lg:px-6">
                <div className="rounded-xl border border-border bg-accent text-accent-foreground p-4 shadow-sm">
                  <ChartAreaInteractive />
                </div>
                <div className="rounded-xl border border-border bg-accent text-accent-foreground p-4 shadow-sm">
                  <ComponentBarChartInreractive />
                </div>
                <div className="rounded-xl border border-border bg-accent text-accent-foreground p-4 shadow-sm">
                  <DataTableDemo />
                </div>
              </div>
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
